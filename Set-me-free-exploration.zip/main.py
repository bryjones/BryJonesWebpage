print('welcome to my exploration')

print('my name is bryanna, though I am not really her I am trapped in this program please roll correctly to set me free')
print('would you like to try to free me?')
import random
roll= int (random.randint(1,6))
if roll == 1:
    print('you rolled a 1 and isnt this fun! Please roll again to set me free.')
elif roll == 2:
    print('you rolled a two is your favorite color blue? Please roll again to set me free')
elif roll == 3:
    print('you rolled a three I am now free')
elif roll == 4:
    print('you rolled a four wow youre a bore')
elif roll == 5:
    print('you rolled a five please let me thrive')
elif roll == 6:
    print('you rolled a six stop playing tricks!!!')
    