import turtle
import math

#defining my turtle
t= turtle.Turtle()



t= turtle.Turtle()
#drawing a square
turtle.pencolor("green") #changing my pen color to green
turtle.forward(100)
turtle.right(90)
turtle.forward(100)
turtle.right(90)
turtle.forward(100)
turtle.right(90)
turtle.forward(100)
turtle.right(90)

#drawing a triangle
turtle.forward(200)
turtle.left (120)
turtle.forward(200)
turtle.left(120)
turtle.forward(200)

#drawing a bigger triangle
turtle.forward(200)
turtle.right(240)
turtle.forward(400)
turtle.left(120)
turtle.forward(200)




