import time
print('welcome to my dungeon game')
time.sleep(1)
question1 = input ('would you like to play? press y for yes and n for no')
if question1 == 'y':
  print('so you think youre brave? HA HA HA')
else:
  print('You think you would get out that easily? Not this time!')
time.sleep(2)

question2 = input('what has hands but cannot clap?')
if question2 == 'a clock':
  print('hmm you think you can win not on my watch!')
else:
  print('your wrong answers only bring you closer to me!')
time.sleep(2)

question3 = input('which letter of the alphabet has more water?')
if question3 == 'c':
  print('okay, okay, I see you')
else:
  print('So close that I can smell you!')

question4 = input('In a one-story pink house, there was a pink person, a pink cat, a pink fish, a pink computer, a pink chair, a pink table, a pink telephone, a pink shower– everything was pink! What color were the stairs?')
if question4 == 'there were no stairs':
  print('ROOOAAAARRRR you have defeated meeeeeee nooooooooo')
else: 
  print('you see the monsters eyes and his mouth begins to open showing his sharp white teeth')
  time.sleep(2)
  print('your body beings to drift magically towards him')
  time.sleep(2)
  print('you black out')
  time.sleep(2)
  print('your eyes begin to open')
  time.sleep(2)
  print('you awaken in your empty Computer Science classroom')
  time.sleep(2)
  print('there is nothing but a singular note on your desk from your professor')
  time.sleep(3)
  print(' it reads that due to you falling asleep you did not recieve attendance or participation credit for this day')


  